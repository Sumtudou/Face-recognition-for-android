package com.example.a11630.face_new;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class MainActivity extends AppCompatActivity implements View.OnClickListener{
    Button btn_change,btn_opt,btn_in,btn_delete,btn_out;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
       btn_change=findViewById(R.id.change);
        btn_change.setOnClickListener(this);

        btn_in=findViewById(R.id.in);
        btn_in.setOnClickListener(this);

        btn_opt=findViewById(R.id.opt);
        btn_opt.setOnClickListener(this);

       btn_delete=findViewById(R.id.delete);
        btn_delete.setOnClickListener(this);

        btn_out=findViewById(R.id.out);
        btn_out.setOnClickListener(this);

        MyHelper hhh=new MyHelper(MainActivity.this);
    }


    @Override
    public void onClick(View v) {
        if(v.getId()==R.id.change){
            Intent in=new Intent(this,change.class);
            startActivity(in);
        }
        else if(v.getId()==R.id.in){
            Intent in=new Intent(this,in.class);
            startActivity(in);
        }else  if(v.getId()==R.id.opt){
            Intent in=new Intent(this,opt.class);
            startActivity(in);
        }else if(v.getId()==R.id.delete){
            Intent in=new Intent(this,delete.class);
            startActivity(in);
        }else{
            System system = null;
            system.exit(0);
        }
    }
}
